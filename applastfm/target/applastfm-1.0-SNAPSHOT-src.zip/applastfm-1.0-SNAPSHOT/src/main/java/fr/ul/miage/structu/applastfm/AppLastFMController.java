package fr.ul.miage.structu.applastfm;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AppLastFMController {
  
	@FXML
	Button choix;
	@FXML
	TextArea reponseAPI;
	@FXML
	TextField nomTagIHM; 
	@FXML
	CheckBox choixTag;
	
	@FXML
    private void ouvrirNouvelleInterface() throws Exception {
		reponseAPI.setWrapText(true);
		RequestManager rm = new RequestManager();
        
		reponseAPI.setText(rm.getTagMusicInfo(nomTagIHM.getText()));
        
    }
}
